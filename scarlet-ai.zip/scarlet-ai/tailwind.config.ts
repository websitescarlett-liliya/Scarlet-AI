import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#150A0C",       // base background
        panel: "#1E1214",     // panel/card surface
        line: "#332025",      // hairline borders
        scarlet: "#E23A46",   // primary accent
        "scarlet-dim": "#8A2430",
        gold: "#C99A4B",      // credit / business accent
        parchment: "#F3ECE7", // primary text
        muted: "#9C8A8C"      // secondary text
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "serif"],
        sans: ["var(--font-inter)", "sans-serif"]
      },
      borderRadius: {
        sm: "4px",
        md: "6px"
      }
    }
  },
  plugins: []
};

export default config;
