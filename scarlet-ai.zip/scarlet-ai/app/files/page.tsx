"use client";

import { useState } from "react";
import { FileUp } from "lucide-react";
import PageHeader from "@/components/PageHeader";

export default function FilesPage() {
  const [file, setFile] = useState<File | null>(null);
  const [summary, setSummary] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function upload() {
    if (!file || loading) return;
    setLoading(true);
    setError("");
    setSummary("");
    try {
      const formData = new FormData();
      formData.set("file", file);
      const res = await fetch("/api/files", { method: "POST", body: formData });
      const data = await res.json();
      if (res.ok) setSummary(data.summary);
      else setError(data.error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <PageHeader title="Upload File" desc="Unggah PDF atau gambar, Scarlet AI baca dan ringkas isinya. 2 credit per file." />

      <div className="max-w-3xl mx-auto px-8 py-6 space-y-4">
        <label className="flex flex-col items-center justify-center gap-2 border border-dashed border-line rounded-sm py-10 text-muted cursor-pointer hover:border-scarlet/50 transition-colors">
          <FileUp size={22} />
          <span className="text-sm">{file ? file.name : "Klik untuk pilih PDF atau gambar"}</span>
          <input
            type="file"
            accept="application/pdf,image/*"
            className="hidden"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          />
        </label>

        <button
          onClick={upload}
          disabled={loading || !file}
          className="px-5 py-2.5 bg-scarlet text-ink rounded-sm text-sm font-medium hover:bg-scarlet/90 disabled:opacity-50 focus-ring"
        >
          {loading ? "Membaca file..." : "Ringkas File"}
        </button>

        {error && <p className="text-sm text-scarlet">⚠️ {error}</p>}
        {summary && (
          <div className="border border-line rounded-sm p-4 whitespace-pre-wrap text-sm text-parchment bg-panel">
            {summary}
          </div>
        )}
      </div>
    </div>
  );
}
