"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  async function submit() {
    setError("");
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    if (res.ok) router.push("/dashboard");
    else setError((await res.json()).error);
  }

  return (
    <div className="max-w-sm mx-auto mt-20 px-6">
      <h1 className="font-display text-3xl text-parchment mb-1">Masuk</h1>
      <p className="text-sm text-muted mb-8">Lanjut ke akun Scarlet AI kamu.</p>

      <div className="space-y-3">
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full bg-panel border border-line rounded-sm px-4 py-2.5 text-sm text-parchment placeholder:text-muted focus-ring"
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full bg-panel border border-line rounded-sm px-4 py-2.5 text-sm text-parchment placeholder:text-muted focus-ring"
        />
        {error && <p className="text-sm text-scarlet">⚠️ {error}</p>}
        <button
          onClick={submit}
          className="w-full py-2.5 bg-scarlet text-ink rounded-sm text-sm font-medium hover:bg-scarlet/90 focus-ring"
        >
          Masuk
        </button>
      </div>

      <p className="text-sm text-muted mt-6">
        Belum punya akun?{" "}
        <a href="/register" className="text-scarlet hover:underline">
          Daftar
        </a>
      </p>
    </div>
  );
}
