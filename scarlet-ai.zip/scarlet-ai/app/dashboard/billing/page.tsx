"use client";

import { useState } from "react";
import PageHeader from "@/components/PageHeader";

const PACKAGES = [
  { id: "starter", credits: 100, priceIdr: 25_000 },
  { id: "pro", credits: 500, priceIdr: 100_000 },
  { id: "power", credits: 1500, priceIdr: 250_000 }
];

export default function BillingPage() {
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [credits, setCredits] = useState<number | null>(null);

  async function buy(packageId: string) {
    setLoadingId(packageId);
    try {
      // In production this should first open the Midtrans/Xendit
      // checkout, then only call this endpoint from the payment
      // webhook once payment is confirmed — see app/api/credits/route.ts.
      const res = await fetch("/api/credits", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ packageId })
      });
      const data = await res.json();
      if (res.ok) setCredits(data.credits);
    } finally {
      setLoadingId(null);
    }
  }

  return (
    <div>
      <PageHeader title="Isi Ulang Credit" desc="Pilih paket sesuai kebutuhan pemakaian." />

      <div className="max-w-3xl mx-auto px-8 py-6">
        {credits !== null && (
          <p className="text-sm text-parchment mb-4">
            Berhasil! Sisa credit sekarang: <span className="text-gold font-medium">{credits}</span>
          </p>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {PACKAGES.map((p) => (
            <div key={p.id} className="border border-line rounded-sm p-5 flex flex-col">
              <p className="text-2xl font-display text-parchment">{p.credits}</p>
              <p className="text-sm text-muted mb-4">credit</p>
              <p className="text-lg text-gold mb-4">Rp {p.priceIdr.toLocaleString("id-ID")}</p>
              <button
                onClick={() => buy(p.id)}
                disabled={loadingId === p.id}
                className="mt-auto w-full py-2 bg-scarlet text-ink rounded-sm text-sm font-medium hover:bg-scarlet/90 disabled:opacity-50 focus-ring"
              >
                {loadingId === p.id ? "Memproses..." : "Beli"}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
