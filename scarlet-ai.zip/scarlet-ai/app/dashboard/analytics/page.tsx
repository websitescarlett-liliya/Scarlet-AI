import PageHeader from "@/components/PageHeader";
import UsageChart from "@/components/UsageChart";
import { getCurrentUser } from "@/lib/currentUser";
import { db } from "@/lib/db";

export default async function AnalyticsPage() {
  const user = await getCurrentUser();
  if (!user) return <p className="p-8 text-muted text-sm">Kamu belum masuk.</p>;

  const logs = await db.usageLog.groupBy({
    by: ["endpoint"],
    where: { userId: user.id },
    _count: { endpoint: true }
  });

  const data = logs.map((l) => ({ endpoint: l.endpoint, count: l._count.endpoint }));

  const [totalCreditsUsed, totalRequests] = await Promise.all([
    db.creditTransaction.aggregate({
      where: { userId: user.id, amount: { lt: 0 } },
      _sum: { amount: true }
    }),
    db.usageLog.count({ where: { userId: user.id } })
  ]);

  return (
    <div>
      <PageHeader title="Analytics" desc="Pemakaian API dan fitur kamu di Scarlet AI." />

      <div className="max-w-3xl mx-auto px-8 py-6 space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="border border-line rounded-sm p-5">
            <p className="text-2xl font-display text-parchment">{totalRequests}</p>
            <p className="text-sm text-muted">Total request</p>
          </div>
          <div className="border border-line rounded-sm p-5">
            <p className="text-2xl font-display text-parchment">
              {Math.abs(totalCreditsUsed._sum.amount ?? 0)}
            </p>
            <p className="text-sm text-muted">Total credit terpakai</p>
          </div>
        </div>

        <div className="border border-line rounded-sm p-5">
          <p className="text-sm text-parchment mb-4">Request per endpoint</p>
          {data.length > 0 ? (
            <UsageChart data={data} />
          ) : (
            <p className="text-sm text-muted">Belum ada data pemakaian.</p>
          )}
        </div>
      </div>
    </div>
  );
}
