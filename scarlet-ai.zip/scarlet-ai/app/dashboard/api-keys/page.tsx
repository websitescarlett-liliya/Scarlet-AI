"use client";

import { useEffect, useState } from "react";
import PageHeader from "@/components/PageHeader";

type ApiKeyRow = {
  id: string;
  label: string;
  keyPrefix: string;
  active: boolean;
  createdAt: string;
  lastUsedAt: string | null;
};

export default function ApiKeysPage() {
  const [keys, setKeys] = useState<ApiKeyRow[]>([]);
  const [newKey, setNewKey] = useState<string | null>(null);
  const [label, setLabel] = useState("");

  async function load() {
    const res = await fetch("/api/api-keys");
    if (res.ok) setKeys((await res.json()).keys);
  }

  useEffect(() => {
    load();
  }, []);

  async function create() {
    const res = await fetch("/api/api-keys", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ label: label || "API Key" })
    });
    const data = await res.json();
    if (res.ok) {
      setNewKey(data.apiKey);
      setLabel("");
      load();
    }
  }

  return (
    <div>
      <PageHeader title="API Key" desc="Buat kunci untuk mengakses Scarlet AI dari aplikasi developer kamu." />

      <div className="max-w-3xl mx-auto px-8 py-6 space-y-6">
        <div className="flex gap-2">
          <input
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="Nama key, misal: Server Produksi"
            className="flex-1 bg-panel border border-line rounded-sm px-4 py-2.5 text-sm text-parchment placeholder:text-muted focus-ring"
          />
          <button
            onClick={create}
            className="px-4 py-2.5 bg-scarlet text-ink rounded-sm text-sm font-medium hover:bg-scarlet/90 focus-ring"
          >
            Buat Key
          </button>
        </div>

        {newKey && (
          <div className="border border-gold/50 rounded-sm p-4 bg-gold/10">
            <p className="text-sm text-parchment mb-2">
              Simpan key ini sekarang — hanya ditampilkan sekali:
            </p>
            <code className="text-gold text-sm break-all">{newKey}</code>
          </div>
        )}

        <div className="border border-line rounded-sm divide-y divide-line">
          {keys.length === 0 && <p className="p-4 text-sm text-muted">Belum ada API key.</p>}
          {keys.map((k) => (
            <div key={k.id} className="p-4 flex items-center justify-between">
              <div>
                <p className="text-sm text-parchment">{k.label}</p>
                <p className="text-xs text-muted">
                  {k.keyPrefix}… &middot; dibuat {new Date(k.createdAt).toLocaleDateString("id-ID")}
                </p>
              </div>
              <span className={`text-xs ${k.active ? "text-emerald-400" : "text-muted"}`}>
                {k.active ? "Aktif" : "Nonaktif"}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
