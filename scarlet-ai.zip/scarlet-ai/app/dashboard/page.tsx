import Link from "next/link";
import { Coins, KeyRound, BarChart3 } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import { getCurrentUser } from "@/lib/currentUser";
import { db } from "@/lib/db";

export default async function DashboardPage() {
  const user = await getCurrentUser();

  if (!user) {
    return (
      <div className="max-w-md mx-auto mt-20 text-center">
        <p className="text-parchment mb-4">Kamu belum masuk.</p>
        <Link href="/login" className="text-scarlet hover:underline">
          Masuk ke akun
        </Link>
      </div>
    );
  }

  const [generationCount, conversationCount] = await Promise.all([
    db.generation.count({ where: { userId: user.id } }),
    db.conversation.count({ where: { userId: user.id } })
  ]);

  return (
    <div>
      <PageHeader title={`Halo, ${user.name}`} desc="Ringkasan akun dan pemakaian kamu." />

      <div className="max-w-3xl mx-auto px-8 py-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="border border-line rounded-sm p-5">
          <Coins size={18} className="text-gold mb-3" />
          <p className="text-2xl font-display text-parchment">{user.credits}</p>
          <p className="text-sm text-muted">Sisa credit</p>
          <Link href="/dashboard/billing" className="text-xs text-scarlet hover:underline mt-2 inline-block">
            Isi ulang →
          </Link>
        </div>

        <div className="border border-line rounded-sm p-5">
          <p className="text-2xl font-display text-parchment">{conversationCount}</p>
          <p className="text-sm text-muted">Percakapan chatbot</p>
        </div>

        <div className="border border-line rounded-sm p-5">
          <p className="text-2xl font-display text-parchment">{generationCount}</p>
          <p className="text-sm text-muted">Total generate (teks/gambar/suara)</p>
        </div>

        <Link
          href="/dashboard/api-keys"
          className="border border-line rounded-sm p-5 hover:border-scarlet/50 transition-colors flex items-start gap-3"
        >
          <KeyRound size={18} className="text-scarlet shrink-0 mt-0.5" />
          <div>
            <p className="text-parchment text-sm font-medium">API Key</p>
            <p className="text-xs text-muted">Kelola akses developer</p>
          </div>
        </Link>

        <Link
          href="/dashboard/analytics"
          className="border border-line rounded-sm p-5 hover:border-scarlet/50 transition-colors flex items-start gap-3"
        >
          <BarChart3 size={18} className="text-scarlet shrink-0 mt-0.5" />
          <div>
            <p className="text-parchment text-sm font-medium">Analytics</p>
            <p className="text-xs text-muted">Lihat data pemakaian</p>
          </div>
        </Link>
      </div>
    </div>
  );
}
