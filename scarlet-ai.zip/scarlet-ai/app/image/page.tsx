"use client";

import { useState } from "react";
import PageHeader from "@/components/PageHeader";

export default function ImageGeneratorPage() {
  const [prompt, setPrompt] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function generate() {
    if (!prompt.trim() || loading) return;
    setLoading(true);
    setError("");
    setImageUrl("");
    try {
      const res = await fetch("/api/image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt })
      });
      const data = await res.json();
      if (res.ok) setImageUrl(data.resultUrl);
      else setError(data.error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <PageHeader title="Image Generator" desc="Ketik deskripsi gambar yang kamu mau. 5 credit per gambar." />

      <div className="max-w-3xl mx-auto px-8 py-6 space-y-4">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          rows={3}
          placeholder="Contoh: kucing oranye pakai jaket kulit, gaya ilustrasi retro"
          className="w-full bg-panel border border-line rounded-sm px-4 py-3 text-sm text-parchment placeholder:text-muted focus-ring"
        />

        <button
          onClick={generate}
          disabled={loading}
          className="px-5 py-2.5 bg-scarlet text-ink rounded-sm text-sm font-medium hover:bg-scarlet/90 disabled:opacity-50 focus-ring"
        >
          {loading ? "Menggambar..." : "Generate Gambar"}
        </button>

        {error && <p className="text-sm text-scarlet">⚠️ {error}</p>}

        {imageUrl && (
          <div className="border border-line rounded-sm overflow-hidden">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={imageUrl} alt={prompt} className="w-full" />
          </div>
        )}
      </div>
    </div>
  );
}
