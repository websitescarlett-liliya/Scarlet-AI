"use client";

import { useState } from "react";
import PageHeader from "@/components/PageHeader";

const VOICES = [
  { id: "default", label: "Netral" },
  { id: "warm", label: "Hangat" },
  { id: "energetic", label: "Bersemangat" }
];

export default function TtsPage() {
  const [text, setText] = useState("");
  const [voice, setVoice] = useState(VOICES[0].id);
  const [audioUrl, setAudioUrl] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function generate() {
    if (!text.trim() || loading) return;
    setLoading(true);
    setError("");
    setAudioUrl("");
    try {
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, voice })
      });
      const data = await res.json();
      if (res.ok) setAudioUrl(data.resultUrl);
      else setError(data.error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <PageHeader title="Voice / TTS" desc="Ubah naskah jadi suara. 2 credit per generate." />

      <div className="max-w-3xl mx-auto px-8 py-6 space-y-4">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={5}
          placeholder="Tempel naskah yang mau diubah jadi suara..."
          className="w-full bg-panel border border-line rounded-sm px-4 py-3 text-sm text-parchment placeholder:text-muted focus-ring"
        />

        <div className="flex gap-2">
          {VOICES.map((v) => (
            <button
              key={v.id}
              onClick={() => setVoice(v.id)}
              className={`px-3 py-1.5 rounded-sm text-sm border focus-ring ${
                voice === v.id ? "border-scarlet text-parchment bg-scarlet/15" : "border-line text-muted"
              }`}
            >
              {v.label}
            </button>
          ))}
        </div>

        <button
          onClick={generate}
          disabled={loading}
          className="px-5 py-2.5 bg-scarlet text-ink rounded-sm text-sm font-medium hover:bg-scarlet/90 disabled:opacity-50 focus-ring"
        >
          {loading ? "Memproses..." : "Ubah jadi Suara"}
        </button>

        {error && <p className="text-sm text-scarlet">⚠️ {error}</p>}
        {audioUrl && <audio controls src={audioUrl} className="w-full" />}
      </div>
    </div>
  );
}
