"use client";

import { useState } from "react";
import { Send } from "lucide-react";
import PageHeader from "@/components/PageHeader";

type Turn = { role: "user" | "assistant"; content: string };

export default function ChatPage() {
  const [turns, setTurns] = useState<Turn[]>([]);
  const [input, setInput] = useState("");
  const [conversationId, setConversationId] = useState<string | undefined>();
  const [loading, setLoading] = useState(false);

  async function send() {
    if (!input.trim() || loading) return;
    const message = input;
    setTurns((t) => [...t, { role: "user", content: message }]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId, message })
      });
      const data = await res.json();
      if (res.ok) {
        setConversationId(data.conversationId);
        setTurns((t) => [...t, { role: "assistant", content: data.reply }]);
      } else {
        setTurns((t) => [...t, { role: "assistant", content: `⚠️ ${data.error}` }]);
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex flex-col h-full">
      <PageHeader title="Chatbot" desc="Tanya apa saja, Scarlet AI jawab langsung. 1 credit per pesan." />

      <div className="flex-1 overflow-y-auto px-8 py-6 space-y-4 max-w-3xl w-full mx-auto">
        {turns.length === 0 && (
          <p className="text-muted text-sm">Mulai percakapan dengan mengetik di bawah.</p>
        )}
        {turns.map((t, i) => (
          <div
            key={i}
            className={
              t.role === "user"
                ? "ml-auto max-w-[80%] bg-scarlet/15 border border-scarlet/30 rounded-sm px-4 py-2.5 text-parchment"
                : "mr-auto max-w-[80%] bg-panel border border-line rounded-sm px-4 py-2.5 text-parchment"
            }
          >
            {t.content}
          </div>
        ))}
        {loading && <p className="text-muted text-sm">Scarlet AI sedang mengetik…</p>}
      </div>

      <div className="border-t border-line px-8 py-4">
        <div className="max-w-3xl mx-auto flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Tulis pertanyaan..."
            className="flex-1 bg-panel border border-line rounded-sm px-4 py-2.5 text-sm text-parchment placeholder:text-muted focus-ring"
          />
          <button
            onClick={send}
            disabled={loading}
            className="px-4 py-2.5 bg-scarlet text-ink rounded-sm hover:bg-scarlet/90 disabled:opacity-50 focus-ring"
          >
            <Send size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
