import Link from "next/link";
import {
  MessageSquare,
  PenLine,
  ImageIcon,
  AudioLines,
  FileUp,
  BookMarked
} from "lucide-react";

const MODULES = [
  {
    href: "/chat",
    icon: MessageSquare,
    title: "Chatbot",
    desc: "Tanya apa saja, dapat jawaban langsung dari Scarlet AI."
  },
  {
    href: "/text",
    icon: PenLine,
    title: "Text Generator",
    desc: "Tulis draft artikel, caption, atau email dalam hitungan detik."
  },
  {
    href: "/image",
    icon: ImageIcon,
    title: "Image Generator",
    desc: "Ketik deskripsi, Scarlet AI ubah jadi gambar."
  },
  {
    href: "/tts",
    icon: AudioLines,
    title: "Voice / TTS",
    desc: "Ubah naskah teks jadi suara natural."
  },
  {
    href: "/files",
    icon: FileUp,
    title: "Upload File",
    desc: "Unggah PDF atau gambar, Scarlet AI baca dan ringkas isinya."
  },
  {
    href: "/templates",
    icon: BookMarked,
    title: "Prompt Template",
    desc: "Pakai template siap jadi supaya lebih cepat mulai."
  }
];

export default function HomePage() {
  return (
    <div className="max-w-5xl mx-auto px-8 py-12">
      <p className="text-muted text-sm mb-2">Selamat datang kembali</p>
      <h1 className="font-display text-4xl text-parchment mb-10">
        Mau bikin apa hari ini?
      </h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {MODULES.map(({ href, icon: Icon, title, desc }) => (
          <Link
            key={href}
            href={href}
            className="group border border-line rounded-sm p-5 hover:border-scarlet/50 transition-colors focus-ring"
          >
            <Icon size={22} className="text-scarlet mb-4" strokeWidth={1.75} />
            <h2 className="text-parchment font-medium mb-1">{title}</h2>
            <p className="text-sm text-muted leading-relaxed">{desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
