import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { runChat } from "@/lib/anthropic";
import { getUserIdFromApiKey } from "@/lib/apiKeyAuth";
import { chargeCredit, InsufficientCreditsError } from "@/lib/credits";

/**
 * Public endpoint developers call with their Scarlet AI API key:
 *
 *   curl https://scarlet.ai/api/v1/chat \
 *     -H "Authorization: Bearer sk_live_xxx" \
 *     -H "Content-Type: application/json" \
 *     -d '{"message": "Halo!"}'
 */
export async function POST(req: NextRequest) {
  const userId = await getUserIdFromApiKey(req);
  if (!userId) return NextResponse.json({ error: "API key tidak valid" }, { status: 401 });

  const { message } = await req.json();
  if (!message) return NextResponse.json({ error: "message wajib diisi" }, { status: 400 });

  const start = Date.now();
  let statusCode = 200;

  try {
    await chargeCredit(userId, "chat", "/api/v1/chat");
    const reply = await runChat([{ role: "user", content: message }]);
    return NextResponse.json({ reply });
  } catch (err) {
    statusCode = err instanceof InsufficientCreditsError ? 402 : 500;
    return NextResponse.json({ error: "Gagal memproses permintaan" }, { status: statusCode });
  } finally {
    await db.usageLog.create({
      data: {
        userId,
        endpoint: "/api/v1/chat",
        creditCost: 1,
        latencyMs: Date.now() - start,
        statusCode
      }
    });
  }
}
