import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { generateText } from "@/lib/anthropic";
import { getUserIdFromApiKey } from "@/lib/apiKeyAuth";
import { chargeCredit, InsufficientCreditsError } from "@/lib/credits";

export async function POST(req: NextRequest) {
  const userId = await getUserIdFromApiKey(req);
  if (!userId) return NextResponse.json({ error: "API key tidak valid" }, { status: 401 });

  const { prompt, style } = await req.json();
  if (!prompt) return NextResponse.json({ error: "prompt wajib diisi" }, { status: 400 });

  const start = Date.now();
  let statusCode = 200;

  try {
    await chargeCredit(userId, "text", "/api/v1/text");
    const resultText = await generateText(prompt, style);
    return NextResponse.json({ resultText });
  } catch (err) {
    statusCode = err instanceof InsufficientCreditsError ? 402 : 500;
    return NextResponse.json({ error: "Gagal memproses permintaan" }, { status: statusCode });
  } finally {
    await db.usageLog.create({
      data: {
        userId,
        endpoint: "/api/v1/text",
        creditCost: 1,
        latencyMs: Date.now() - start,
        statusCode
      }
    });
  }
}
