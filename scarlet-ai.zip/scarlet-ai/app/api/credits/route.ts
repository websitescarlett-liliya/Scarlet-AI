import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { topUpCredit } from "@/lib/credits";
import { getUserIdFromRequest } from "@/lib/session";

// Simple package list — adjust prices for the Midtrans/Xendit checkout you create.
export const CREDIT_PACKAGES = [
  { id: "starter", credits: 100, priceIdr: 25_000 },
  { id: "pro", credits: 500, priceIdr: 100_000 },
  { id: "power", credits: 1500, priceIdr: 250_000 }
];

// GET: list available packages for the top-up screen.
export async function GET() {
  return NextResponse.json({ packages: CREDIT_PACKAGES });
}

/**
 * POST: called by your payment provider's webhook once a payment is
 * confirmed (e.g. Midtrans `notification` callback). Verify the
 * provider's signature before trusting this payload in production.
 */
export async function POST(req: NextRequest) {
  const userId = await getUserIdFromRequest(req);
  if (!userId) return NextResponse.json({ error: "Belum login" }, { status: 401 });

  const { packageId } = await req.json();
  const pkg = CREDIT_PACKAGES.find((p) => p.id === packageId);
  if (!pkg) return NextResponse.json({ error: "Paket tidak ditemukan" }, { status: 400 });

  // TODO: replace with a real Midtrans/Xendit charge + webhook
  // verification flow before calling topUpCredit in production.
  await topUpCredit(userId, pkg.credits, `topup_${pkg.id}`);
  const user = await db.user.findUniqueOrThrow({ where: { id: userId } });

  return NextResponse.json({ credits: user.credits });
}
