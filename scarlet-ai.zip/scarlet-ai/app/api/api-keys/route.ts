import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { generateApiKey } from "@/lib/apiKeyAuth";
import { getUserIdFromRequest } from "@/lib/session";

export async function GET(req: NextRequest) {
  const userId = await getUserIdFromRequest(req);
  if (!userId) return NextResponse.json({ error: "Belum login" }, { status: 401 });

  const keys = await db.apiKey.findMany({
    where: { userId },
    select: { id: true, label: true, keyPrefix: true, active: true, createdAt: true, lastUsedAt: true },
    orderBy: { createdAt: "desc" }
  });

  return NextResponse.json({ keys });
}

export async function POST(req: NextRequest) {
  const userId = await getUserIdFromRequest(req);
  if (!userId) return NextResponse.json({ error: "Belum login" }, { status: 401 });

  const { label } = await req.json();
  const { raw, hash, prefix } = generateApiKey();

  await db.apiKey.create({
    data: { userId, label: label || "API Key", keyHash: hash, keyPrefix: prefix }
  });

  // The raw key is only ever shown once — the server only stores its hash.
  return NextResponse.json({ apiKey: raw });
}
