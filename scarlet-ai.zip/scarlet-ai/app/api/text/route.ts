import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { generateText } from "@/lib/anthropic";
import { chargeCredit, refundCredit, InsufficientCreditsError } from "@/lib/credits";
import { getUserIdFromRequest } from "@/lib/session";

export async function POST(req: NextRequest) {
  const userId = await getUserIdFromRequest(req);
  if (!userId) return NextResponse.json({ error: "Belum login" }, { status: 401 });

  const { prompt, style } = await req.json();
  if (!prompt) return NextResponse.json({ error: "Prompt kosong" }, { status: 400 });

  try {
    await chargeCredit(userId, "text", "/api/text");

    let resultText: string;
    try {
      resultText = await generateText(prompt, style);
    } catch (err) {
      await refundCredit(userId, 1, "text");
      throw err;
    }

    await db.generation.create({
      data: { userId, type: "TEXT", prompt, resultText, style, creditCost: 1 }
    });

    return NextResponse.json({ resultText });
  } catch (err) {
    const code = err instanceof InsufficientCreditsError ? 402 : 500;
    return NextResponse.json({ error: "Gagal generate teks" }, { status: code });
  }
}
