import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getUserIdFromRequest } from "@/lib/session";

export async function GET() {
  const templates = await db.promptTemplate.findMany({
    where: { isPublic: true },
    orderBy: { createdAt: "desc" }
  });
  return NextResponse.json({ templates });
}

export async function POST(req: NextRequest) {
  const userId = await getUserIdFromRequest(req);
  if (!userId) return NextResponse.json({ error: "Belum login" }, { status: 401 });

  const { title, body, category } = await req.json();
  if (!title || !body) return NextResponse.json({ error: "Lengkapi judul dan isi" }, { status: 400 });

  const template = await db.promptTemplate.create({
    data: { userId, title, body, category: category || "general" }
  });

  return NextResponse.json({ template });
}
