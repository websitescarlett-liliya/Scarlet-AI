import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { chargeCredit, refundCredit, InsufficientCreditsError } from "@/lib/credits";
import { getUserIdFromRequest } from "@/lib/session";

async function callTtsProvider(text: string, voice: string): Promise<string> {
  const apiKey = process.env.ELEVENLABS_API_KEY;
  if (!apiKey) throw new Error("ELEVENLABS_API_KEY belum diset di .env");

  const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voice}`, {
    method: "POST",
    headers: { "xi-api-key": apiKey, "Content-Type": "application/json" },
    body: JSON.stringify({ text, model_id: "eleven_multilingual_v2" })
  });

  if (!res.ok) throw new Error(`Provider suara gagal: ${res.status}`);

  // Upload the returned audio bytes to object storage and return its URL.
  // Left as a TODO since storage provider is deployment-specific.
  const audioBuffer = await res.arrayBuffer();
  void audioBuffer;
  return "";
}

export async function POST(req: NextRequest) {
  const userId = await getUserIdFromRequest(req);
  if (!userId) return NextResponse.json({ error: "Belum login" }, { status: 401 });

  const { text, voice = "default" } = await req.json();
  if (!text) return NextResponse.json({ error: "Teks kosong" }, { status: 400 });

  try {
    await chargeCredit(userId, "tts", "/api/tts");

    let resultUrl: string;
    try {
      resultUrl = await callTtsProvider(text, voice);
    } catch (err) {
      await refundCredit(userId, 2, "tts");
      throw err;
    }

    await db.generation.create({
      data: { userId, type: "TTS", prompt: text, resultUrl, creditCost: 2 }
    });

    return NextResponse.json({ resultUrl });
  } catch (err) {
    const code = err instanceof InsufficientCreditsError ? 402 : 500;
    const message = err instanceof Error ? err.message : "Gagal generate suara";
    return NextResponse.json({ error: message }, { status: code });
  }
}
