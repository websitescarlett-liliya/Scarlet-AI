import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { summarizeText } from "@/lib/anthropic";
import { chargeCredit, refundCredit, InsufficientCreditsError } from "@/lib/credits";
import { getUserIdFromRequest } from "@/lib/session";

/**
 * Extracts raw text from an uploaded PDF or image.
 * - PDF: use a library like `pdf-parse` (text) or OCR for scanned pages.
 * - Image: send to a vision-capable model or OCR provider.
 * Swap the body of this function for your chosen extraction method.
 */
async function extractText(file: File): Promise<string> {
  if (file.type === "application/pdf") {
    // TODO: integrate pdf-parse or a similar library here.
    throw new Error("Ekstraksi PDF belum dihubungkan — lihat komentar di extractText()");
  }
  if (file.type.startsWith("image/")) {
    // TODO: send image bytes to a vision model for OCR/description.
    throw new Error("Ekstraksi gambar belum dihubungkan — lihat komentar di extractText()");
  }
  throw new Error("Tipe file tidak didukung");
}

export async function POST(req: NextRequest) {
  const userId = await getUserIdFromRequest(req);
  if (!userId) return NextResponse.json({ error: "Belum login" }, { status: 401 });

  const formData = await req.formData();
  const file = formData.get("file") as File | null;
  if (!file) return NextResponse.json({ error: "File tidak ditemukan" }, { status: 400 });

  try {
    await chargeCredit(userId, "file_summary", "/api/files");

    let summary: string;
    try {
      const extracted = await extractText(file);
      summary = await summarizeText(extracted);
    } catch (err) {
      await refundCredit(userId, 2, "file_summary");
      throw err;
    }

    // Upload the original file to object storage and store its URL —
    // left as a TODO since storage is deployment-specific.
    const fileUrl = "";

    const record = await db.fileUpload.create({
      data: { userId, fileName: file.name, fileUrl, fileType: file.type, summary }
    });

    return NextResponse.json({ id: record.id, summary });
  } catch (err) {
    const code = err instanceof InsufficientCreditsError ? 402 : 500;
    const message = err instanceof Error ? err.message : "Gagal memproses file";
    return NextResponse.json({ error: message }, { status: code });
  }
}
