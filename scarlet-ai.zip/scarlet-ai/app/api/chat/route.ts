import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { runChat } from "@/lib/anthropic";
import { chargeCredit, refundCredit, InsufficientCreditsError } from "@/lib/credits";
import { getUserIdFromRequest } from "@/lib/session";

export async function POST(req: NextRequest) {
  const userId = await getUserIdFromRequest(req);
  if (!userId) return NextResponse.json({ error: "Belum login" }, { status: 401 });

  const { conversationId, message } = await req.json();
  if (!message) return NextResponse.json({ error: "Pesan kosong" }, { status: 400 });

  const start = Date.now();
  let statusCode = 200;

  try {
    await chargeCredit(userId, "chat", "/api/chat");

    const conversation = conversationId
      ? await db.conversation.findUniqueOrThrow({
          where: { id: conversationId },
          include: { messages: { orderBy: { createdAt: "asc" } } }
        })
      : await db.conversation.create({
          data: { userId, title: message.slice(0, 40) },
          include: { messages: true }
        });

    await db.message.create({
      data: { conversationId: conversation.id, role: "USER", content: message }
    });

    const history = [...conversation.messages, { role: "USER" as const, content: message }].map((m) => ({
      role: m.role === "USER" ? ("user" as const) : ("assistant" as const),
      content: m.content
    }));

    let reply: string;
    try {
      reply = await runChat(history);
    } catch (err) {
      await refundCredit(userId, 1, "chat");
      throw err;
    }

    await db.message.create({
      data: { conversationId: conversation.id, role: "ASSISTANT", content: reply }
    });

    return NextResponse.json({ conversationId: conversation.id, reply });
  } catch (err) {
    statusCode = err instanceof InsufficientCreditsError ? 402 : 500;
    return NextResponse.json(
      { error: err instanceof InsufficientCreditsError ? "Credit tidak cukup" : "Terjadi kesalahan" },
      { status: statusCode }
    );
  } finally {
    await db.usageLog.create({
      data: {
        userId,
        endpoint: "/api/chat",
        creditCost: 1,
        latencyMs: Date.now() - start,
        statusCode
      }
    });
  }
}
