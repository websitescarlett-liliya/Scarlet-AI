import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { chargeCredit, refundCredit, InsufficientCreditsError } from "@/lib/credits";
import { getUserIdFromRequest } from "@/lib/session";

/**
 * Calls your chosen image-generation provider. Swap this out for a
 * real call to Stability AI, OpenAI Images, or another provider —
 * kept separate so it's a one-function change.
 */
async function callImageProvider(prompt: string): Promise<string> {
  const apiKey = process.env.STABILITY_API_KEY;
  if (!apiKey) {
    throw new Error("STABILITY_API_KEY belum diset di .env");
  }

  // Example shape for Stability AI's REST API — adjust to the
  // provider you actually integrate.
  const res = await fetch("https://api.stability.ai/v2beta/stable-image/generate/core", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, Accept: "application/json" },
    body: (() => {
      const form = new FormData();
      form.set("prompt", prompt);
      form.set("output_format", "png");
      return form;
    })()
  });

  if (!res.ok) throw new Error(`Provider gambar gagal: ${res.status}`);
  const data = await res.json();
  // Upload data.image (base64) to your object storage and return its URL.
  // Left as a TODO since storage provider is deployment-specific.
  return data.imageUrl ?? "";
}

export async function POST(req: NextRequest) {
  const userId = await getUserIdFromRequest(req);
  if (!userId) return NextResponse.json({ error: "Belum login" }, { status: 401 });

  const { prompt } = await req.json();
  if (!prompt) return NextResponse.json({ error: "Prompt kosong" }, { status: 400 });

  try {
    await chargeCredit(userId, "image", "/api/image");

    let resultUrl: string;
    try {
      resultUrl = await callImageProvider(prompt);
    } catch (err) {
      await refundCredit(userId, 5, "image");
      throw err;
    }

    await db.generation.create({
      data: { userId, type: "IMAGE", prompt, resultUrl, creditCost: 5 }
    });

    return NextResponse.json({ resultUrl });
  } catch (err) {
    const code = err instanceof InsufficientCreditsError ? 402 : 500;
    const message = err instanceof Error ? err.message : "Gagal generate gambar";
    return NextResponse.json({ error: message }, { status: code });
  }
}
