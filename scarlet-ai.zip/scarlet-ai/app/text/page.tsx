"use client";

import { useState } from "react";
import PageHeader from "@/components/PageHeader";

const STYLES = ["Formal", "Santai", "Persuasif", "Storytelling", "Ringkas"];

export default function TextGeneratorPage() {
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState(STYLES[0]);
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  async function generate() {
    if (!prompt.trim() || loading) return;
    setLoading(true);
    setResult("");
    try {
      const res = await fetch("/api/text", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, style })
      });
      const data = await res.json();
      setResult(res.ok ? data.resultText : `⚠️ ${data.error}`);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <PageHeader title="Text Generator" desc="Jelaskan yang mau ditulis, pilih gaya bahasa. 1 credit per generate." />

      <div className="max-w-3xl mx-auto px-8 py-6 space-y-4">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          rows={4}
          placeholder="Contoh: caption Instagram promo kopi susu untuk anak muda"
          className="w-full bg-panel border border-line rounded-sm px-4 py-3 text-sm text-parchment placeholder:text-muted focus-ring"
        />

        <div className="flex flex-wrap gap-2">
          {STYLES.map((s) => (
            <button
              key={s}
              onClick={() => setStyle(s)}
              className={`px-3 py-1.5 rounded-sm text-sm border focus-ring ${
                style === s ? "border-scarlet text-parchment bg-scarlet/15" : "border-line text-muted"
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        <button
          onClick={generate}
          disabled={loading}
          className="px-5 py-2.5 bg-scarlet text-ink rounded-sm text-sm font-medium hover:bg-scarlet/90 disabled:opacity-50 focus-ring"
        >
          {loading ? "Menulis..." : "Generate"}
        </button>

        {result && (
          <div className="border border-line rounded-sm p-4 whitespace-pre-wrap text-sm text-parchment bg-panel">
            {result}
          </div>
        )}
      </div>
    </div>
  );
}
