"use client";

import { useEffect, useState } from "react";
import PageHeader from "@/components/PageHeader";

type Template = { id: string; title: string; body: string; category: string };

export default function TemplatesPage() {
  const [templates, setTemplates] = useState<Template[]>([]);

  useEffect(() => {
    fetch("/api/templates")
      .then((r) => r.json())
      .then((d) => setTemplates(d.templates ?? []));
  }, []);

  return (
    <div>
      <PageHeader title="Prompt Template" desc="Pakai template siap jadi, tinggal sesuaikan lalu kirim ke Chatbot atau Text Generator." />

      <div className="max-w-3xl mx-auto px-8 py-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
        {templates.length === 0 && (
          <p className="text-sm text-muted sm:col-span-2">Belum ada template publik. Tambahkan lewat API /api/templates.</p>
        )}
        {templates.map((t) => (
          <div key={t.id} className="border border-line rounded-sm p-4">
            <p className="text-xs text-scarlet mb-1 uppercase tracking-wide">{t.category}</p>
            <p className="text-parchment font-medium mb-2">{t.title}</p>
            <p className="text-sm text-muted line-clamp-3">{t.body}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
