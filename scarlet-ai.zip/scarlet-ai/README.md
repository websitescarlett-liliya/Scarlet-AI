# Scarlet AI

Platform AI: chatbot, text generator, image generator, voice/TTS, upload &
ringkas file, plus sisi bisnis (login, sistem credit, API developer,
analytics).

## Fitur

**Inti**
- Chatbot (tanya jawab, riwayat percakapan tersimpan)
- Text Generator (dengan pilihan gaya bahasa)
- Image Generator (stub — tinggal sambungkan provider)
- Voice/TTS (stub — tinggal sambungkan provider)
- Upload File → ringkas PDF/gambar (ekstraksi teks perlu disambungkan)

**Retensi**
- Prompt Template (galeri publik + simpan sendiri via API)
- History otomatis untuk semua generation

**Bisnis**
- Login/Register + Dashboard
- Sistem credit (charge otomatis per fitur, refund kalau provider gagal)
- API key untuk developer (`/api/v1/chat`, `/api/v1/text`)
- Analytics pemakaian per endpoint

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Salin `.env.example` jadi `.env` dan isi:
   - `DATABASE_URL` — koneksi PostgreSQL
   - `JWT_SECRET` — string acak panjang
   - `ANTHROPIC_API_KEY` — untuk chatbot & text generator
   - `STABILITY_API_KEY` / provider gambar pilihanmu
   - `ELEVENLABS_API_KEY` / provider suara pilihanmu
   - `MIDTRANS_SERVER_KEY` & `MIDTRANS_CLIENT_KEY` — untuk isi ulang credit

3. Migrasi database:
   ```bash
   npx prisma migrate dev --name init
   ```

4. Jalankan:
   ```bash
   npm run dev
   ```

## Yang masih perlu disambungkan sebelum production

- **Ekstraksi PDF/gambar** di `app/api/files/route.ts` (`extractText`) — pasang
  library seperti `pdf-parse` untuk PDF dan model vision/OCR untuk gambar.
- **Object storage** untuk file hasil generate (gambar, audio, file upload) —
  saat ini fungsi provider mengembalikan URL kosong; sambungkan ke S3,
  Supabase Storage, atau Cloudflare R2.
- **Provider gambar & suara** — ganti stub di `app/api/image/route.ts` dan
  `app/api/tts/route.ts` sesuai provider yang dipilih.
- **Verifikasi webhook pembayaran** — `app/api/credits/route.ts` saat ini
  langsung top-up tanpa verifikasi signature; di production, validasi
  callback dari Midtrans/Xendit dulu sebelum menambah credit.
- **Rate limiting** untuk `/api/v1/*` — tambahkan middleware rate limit
  berbasis `PUBLIC_API_RATE_LIMIT_*` di `.env`.

## Struktur folder

```
app/
  chat/ text/ image/ tts/ files/ templates/   → halaman fitur inti
  login/ register/                            → autentikasi
  dashboard/                                  → overview, billing, api-keys, analytics
  api/                                        → route handler internal (dipakai frontend)
  api/v1/                                     → API publik untuk developer (autentikasi via API key)
components/                                   → Sidebar, TopBar, PageHeader, UsageChart
lib/                                          → db, auth, session, credits, anthropic, apiKeyAuth
prisma/schema.prisma                          → skema database lengkap
```
