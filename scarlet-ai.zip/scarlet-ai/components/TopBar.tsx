import Link from "next/link";
import { Coins } from "lucide-react";

// In a real build, fetch the signed-in user's credit balance server-side
// (see lib/credits.ts) instead of this placeholder value.
const PLACEHOLDER_CREDITS = 128;

export default function TopBar() {
  return (
    <header className="h-14 shrink-0 border-b border-line flex items-center justify-end gap-3 px-6">
      <Link
        href="/dashboard/billing"
        className="flex items-center gap-2 px-3 py-1.5 rounded-sm border border-line text-sm text-parchment hover:border-gold/60 transition-colors focus-ring"
      >
        <Coins size={15} className="text-gold" />
        {PLACEHOLDER_CREDITS} credit
      </Link>
      <Link
        href="/login"
        className="px-3 py-1.5 rounded-sm bg-scarlet text-ink text-sm font-medium hover:bg-scarlet/90 transition-colors focus-ring"
      >
        Akun
      </Link>
    </header>
  );
}
