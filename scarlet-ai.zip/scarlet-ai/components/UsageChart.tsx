"use client";

import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

export default function UsageChart({ data }: { data: { endpoint: string; count: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={data}>
        <CartesianGrid stroke="#332025" vertical={false} />
        <XAxis dataKey="endpoint" stroke="#9C8A8C" fontSize={12} />
        <YAxis stroke="#9C8A8C" fontSize={12} allowDecimals={false} />
        <Tooltip
          contentStyle={{ background: "#1E1214", border: "1px solid #332025", color: "#F3ECE7" }}
          cursor={{ fill: "rgba(226,58,70,0.08)" }}
        />
        <Bar dataKey="count" fill="#E23A46" radius={[3, 3, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
