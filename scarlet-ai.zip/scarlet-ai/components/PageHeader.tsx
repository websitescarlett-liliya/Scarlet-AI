export default function PageHeader({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="px-8 pt-10 pb-6 border-b border-line">
      <h1 className="font-display text-3xl text-parchment mb-1">{title}</h1>
      <p className="text-sm text-muted max-w-xl">{desc}</p>
    </div>
  );
}
