"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  MessageSquare,
  PenLine,
  ImageIcon,
  AudioLines,
  FileUp,
  LayoutDashboard,
  BookMarked
} from "lucide-react";
import clsx from "clsx";

const NAV = [
  { href: "/chat", label: "Chatbot", icon: MessageSquare },
  { href: "/text", label: "Text Generator", icon: PenLine },
  { href: "/image", label: "Image Generator", icon: ImageIcon },
  { href: "/tts", label: "Voice / TTS", icon: AudioLines },
  { href: "/files", label: "Upload File", icon: FileUp },
  { href: "/templates", label: "Prompt Template", icon: BookMarked },
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard }
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-60 shrink-0 border-r border-line bg-panel flex flex-col">
      <div className="px-5 py-6">
        <Link href="/" className="flex items-baseline gap-2">
          <span className="font-display text-2xl text-parchment">Scarlet</span>
          <span className="font-display text-2xl text-scarlet">AI</span>
        </Link>
      </div>

      <nav className="flex-1 px-3 space-y-1">
        {NAV.map(({ href, label, icon: Icon }) => {
          const active = pathname?.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={clsx(
                "flex items-center gap-3 px-3 py-2 rounded-sm text-sm transition-colors focus-ring",
                active
                  ? "bg-scarlet/15 text-parchment border border-scarlet/40"
                  : "text-muted hover:text-parchment hover:bg-white/5 border border-transparent"
              )}
            >
              <Icon size={17} strokeWidth={1.75} />
              {label}
            </Link>
          );
        })}
      </nav>

      <div className="px-5 py-5 border-t border-line text-xs text-muted">
        Scarlet AI &middot; v0.1
      </div>
    </aside>
  );
}
