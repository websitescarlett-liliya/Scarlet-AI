import { cookies } from "next/headers";
import { verifySession } from "@/lib/auth";
import { db } from "@/lib/db";

export async function getCurrentUser() {
  const token = cookies().get("scarlet_session")?.value;
  if (!token) return null;

  const payload = verifySession(token);
  if (!payload) return null;

  return db.user.findUnique({ where: { id: payload.sub } });
}
