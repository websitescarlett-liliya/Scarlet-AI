import { NextRequest } from "next/server";
import { verifySession } from "@/lib/auth";

/**
 * Reads the `scarlet_session` cookie set at login (see
 * app/api/auth/login/route.ts) and returns the user id, or null
 * if the request is unauthenticated / the token is invalid.
 */
export async function getUserIdFromRequest(req: NextRequest): Promise<string | null> {
  const token = req.cookies.get("scarlet_session")?.value;
  if (!token) return null;

  const payload = verifySession(token);
  return payload?.sub ?? null;
}
