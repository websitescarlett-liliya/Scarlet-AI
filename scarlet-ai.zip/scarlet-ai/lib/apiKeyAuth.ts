import crypto from "crypto";
import { NextRequest } from "next/server";
import { db } from "@/lib/db";

function hashKey(rawKey: string) {
  return crypto.createHash("sha256").update(rawKey).digest("hex");
}

export function generateApiKey() {
  const raw = `sk_live_${crypto.randomBytes(24).toString("hex")}`;
  return { raw, hash: hashKey(raw), prefix: raw.slice(0, 12) };
}

/**
 * Resolves the request's `Authorization: Bearer sk_live_...` header
 * to a userId, for use in /api/v1/* public developer endpoints.
 */
export async function getUserIdFromApiKey(req: NextRequest): Promise<string | null> {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) return null;

  const raw = authHeader.slice("Bearer ".length).trim();
  const keyHash = hashKey(raw);

  const key = await db.apiKey.findUnique({ where: { keyHash } });
  if (!key || !key.active) return null;

  await db.apiKey.update({ where: { id: key.id }, data: { lastUsedAt: new Date() } });
  return key.userId;
}
