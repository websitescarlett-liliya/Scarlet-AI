import Anthropic from "@anthropic-ai/sdk";

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY
});

export type ChatTurn = { role: "user" | "assistant"; content: string };

/**
 * Powers the Chatbot module (Q&A) and can be reused for Translate
 * by passing a system prompt that instructs a translation task.
 */
export async function runChat(messages: ChatTurn[], system?: string) {
  const response = await anthropic.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 1024,
    system,
    messages
  });

  const textBlock = response.content.find((block) => block.type === "text");
  return textBlock && "text" in textBlock ? textBlock.text : "";
}

/**
 * Powers the Text Generator module. `style` maps to "gaya bahasa"
 * (formal, casual, persuasive, dsb) selected by the user.
 */
export async function generateText(prompt: string, style?: string) {
  const system = style
    ? `Kamu adalah asisten menulis. Tulis dalam gaya bahasa: ${style}. Balas hanya dengan tulisan jadi, tanpa basa-basi pembuka.`
    : "Kamu adalah asisten menulis. Balas hanya dengan tulisan jadi, tanpa basa-basi pembuka.";

  return runChat([{ role: "user", content: prompt }], system);
}

/**
 * Powers file summarization after text has been extracted from a
 * PDF/image upload (see app/api/files/route.ts).
 */
export async function summarizeText(extractedText: string) {
  const system =
    "Ringkas dokumen berikut dalam Bahasa Indonesia, singkat, padat, poin-poin utama saja.";
  return runChat([{ role: "user", content: extractedText }], system);
}
