import { db } from "@/lib/db";

export const CREDIT_COST: Record<string, number> = {
  chat: 1,
  text: 1,
  image: 5,
  tts: 2,
  file_summary: 2,
  translate: 1
};

export class InsufficientCreditsError extends Error {
  constructor() {
    super("Credit tidak cukup");
    this.name = "InsufficientCreditsError";
  }
}

/**
 * Atomically checks and deducts credit for a feature usage, and
 * records both a CreditTransaction and a UsageLog row. Call this
 * BEFORE calling the AI provider so users never pay for a failed
 * generation twice, and refund with `refundCredit` on provider error.
 */
export async function chargeCredit(userId: string, feature: keyof typeof CREDIT_COST, endpoint: string) {
  const cost = CREDIT_COST[feature] ?? 1;

  const result = await db.$transaction(async (tx) => {
    const user = await tx.user.findUniqueOrThrow({ where: { id: userId } });
    if (user.credits < cost) {
      throw new InsufficientCreditsError();
    }

    await tx.user.update({
      where: { id: userId },
      data: { credits: { decrement: cost } }
    });

    await tx.creditTransaction.create({
      data: { userId, amount: -cost, reason: feature }
    });

    return cost;
  });

  return result;
}

export async function refundCredit(userId: string, amount: number, reason: string) {
  await db.$transaction([
    db.user.update({ where: { id: userId }, data: { credits: { increment: amount } } }),
    db.creditTransaction.create({ data: { userId, amount, reason: `refund_${reason}` } })
  ]);
}

export async function topUpCredit(userId: string, amount: number, reason = "topup") {
  await db.$transaction([
    db.user.update({ where: { id: userId }, data: { credits: { increment: amount } } }),
    db.creditTransaction.create({ data: { userId, amount, reason } })
  ]);
}
